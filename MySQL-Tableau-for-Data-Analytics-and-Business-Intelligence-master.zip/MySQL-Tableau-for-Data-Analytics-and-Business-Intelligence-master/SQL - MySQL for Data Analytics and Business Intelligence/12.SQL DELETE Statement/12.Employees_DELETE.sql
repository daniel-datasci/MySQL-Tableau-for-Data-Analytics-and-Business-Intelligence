/*Remove the department number 10 record from the “departments” table.*/
SELECT *
FROM departments;

DELETE FROM departments
WHERE dept_no = 'd010';